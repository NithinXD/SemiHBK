package com.example.emptyactivity;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.content.DialogInterface;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NextActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private EditText editTextDate;
    private String selectedTime;
    private List<String> bookedTimeSlots;
    private Button updateButton;
    private Calendar myCalendar;
    private AlertDialog.Builder alertDialogBuilder;
    private ConstraintLayout frameLayout;
    private Button selectedButton; // To store the currently selected button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        editTextDate = findViewById(R.id.editTextDate);
        myCalendar = Calendar.getInstance();
        frameLayout = findViewById(R.id.frameLayout);
        frameLayout.setVisibility(View.GONE); // Initially hide the frameLayout
        bookedTimeSlots = new ArrayList<>();

        db = FirebaseFirestore.getInstance();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDate();
                frameLayout.setVisibility(View.VISIBLE); // Show frameLayout after selecting date
                checkBookedTimeSlots(); // Check slots when date is selected
            }
        };

        editTextDate.setOnClickListener(v -> new DatePickerDialog(NextActivity.this, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show());

        Button checkSlotsButton = findViewById(R.id.button2);
        checkSlotsButton.setOnClickListener(v -> checkBookedTimeSlots());

        Button bookButton = findViewById(R.id.button);
        bookButton.setOnClickListener(v -> {
            if (isDateEntered()) {
                navigateToBookingActivity();
            } else {
                Toast.makeText(NextActivity.this, "Please enter the date", Toast.LENGTH_SHORT).show();
            }
        });

        updateButton = findViewById(R.id.button17);
        updateButton.setOnClickListener(v -> {
            if (isSlotBooked(selectedTime)) {
                if (isDateEntered() && selectedTime != null && !selectedTime.isEmpty()) {
                    showUpdateDialog(editTextDate.getText().toString(), selectedTime);
                } else {
                    Toast.makeText(NextActivity.this, "Please select a valid date and slot", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(NextActivity.this, "No booking found for selected date and slot", Toast.LENGTH_SHORT).show();
            }
        });

        Button deleteButton = findViewById(R.id.button14);
        deleteButton.setOnClickListener(v -> {
            if (isSlotBooked(selectedTime)) {
                if (isDateEntered() && selectedTime != null && !selectedTime.isEmpty()) {
                    deleteBooking(editTextDate.getText().toString(), selectedTime);
                } else {
                    Toast.makeText(NextActivity.this, "Please select a valid date and slot", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(NextActivity.this, "No booking found for selected date and slot", Toast.LENGTH_SHORT).show();
            }
        });

        // Set click listener for all buttons inside frameLayout
        for (int i = 4; i <= 12; i++) {
            int buttonId = getResources().getIdentifier("button" + i, "id", getPackageName());
            Button but = findViewById(buttonId);
            but.setOnClickListener(v -> {
                if (selectedButton != null) {
                    selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark)); // Reset previous selection
                }
                v.setBackgroundColor(getResources().getColor(R.color.blue)); // Set clicked button to blue
                selectedButton = (Button) v;
                selectedTime = ((Button) v).getText().toString();
            });
        }
    }
    @Override
    public void onBackPressed() {
        showExitConfirmationDialog();
    }
    private void showExitConfirmationDialog() {
        alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Alert");
        alertDialogBuilder.setIcon(R.drawable.ic_baseline_announcement_24);
        alertDialogBuilder.setMessage("Do you want to exit?");
        alertDialogBuilder.setCancelable(false);

        alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finishAffinity(); // Exit from the app
            }
        });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); // Dismiss the dialog and remain on the same page
            }
        });

        // Create and show the alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void updateDate() {
        String myFormat = "dd/MM/yyyy"; // Change date format as needed
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editTextDate.setText(sdf.format(myCalendar.getTime()));
        resetButtons();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.item_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){

            case R.id.Bookingmenu:
                Toast.makeText(this, "View Bookings", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, Schedule.class));
                return true;


            case R.id.logoutmenu:
                Toast.makeText(this, "Logout page", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void checkBookedTimeSlots() {
        // Reset button colors to default initially
        resetButtons();

        String selectedDate = editTextDate.getText().toString();

        db.collection("bookings")
                .whereEqualTo("date", selectedDate)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        bookedTimeSlots.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String bookedTimeSlot = document.getString("timeSlot");
                            String status = document.getString("status");
                            if (bookedTimeSlot != null && status != null) {
                                bookedTimeSlots.add(bookedTimeSlot);
                                if (status.equals("approved")) {
                                    setButtonColor(bookedTimeSlot, Color.RED); // Approved bookings in red
                                } else if (status.equals("pending")) {
                                    setButtonColor(bookedTimeSlot, Color.YELLOW); // Pending bookings in yellow
                                }
                            }
                        }
                    } else {
                        Toast.makeText(NextActivity.this, "Error getting booked time slots", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void resetButtons() {
        for (int i = 4; i <= 12; i++) {
            int buttonId = getResources().getIdentifier("button" + i, "id", getPackageName());
            Button but = findViewById(buttonId);
            but.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark)); // Reset to default color
        }
    }

    private void setButtonColor(String timeSlot, int color) {
        int buttonId = getResources().getIdentifier("button" + timeSlot, "id", getPackageName());
        Button button = findViewById(buttonId);
        if (button != null) {
            button.setBackgroundColor(color);
        }
    }

    private boolean isSlotBooked(String timeSlot) {
        return bookedTimeSlots.contains(timeSlot);
    }

    private boolean isDateEntered() {
        return !editTextDate.getText().toString().isEmpty();
    }

    private void navigateToBookingActivity() {
        Intent intent = new Intent(NextActivity.this, BookingActivity.class);
        intent.putExtra("selected_date", editTextDate.getText().toString());
        intent.putExtra("selected_time_slot", selectedTime);
        startActivity(intent);
    }

    private void showUpdateDialog(final String date, final String timeSlot) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Booking");
        builder.setMessage("Do you want to update this booking?");

        builder.setPositiveButton("Yes", (dialog, which) -> {
            updateBookingStatus(date, timeSlot, "pending");
            dialog.dismiss();
        });

        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void updateBookingStatus(String date, String timeSlot, String status) {
        db.collection("bookings")
                .whereEqualTo("date", date)
                .whereEqualTo("timeSlot", timeSlot)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && !task.getResult().isEmpty()) {
                        String bookingId = task.getResult().getDocuments().get(0).getId();
                        db.collection("bookings").document(bookingId).update("status", status)
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(NextActivity.this, "Booking " + status, Toast.LENGTH_SHORT).show();
                                    checkBookedTimeSlots(); // Refresh the UI to reflect status changes
                                })
                                .addOnFailureListener(e -> Toast.makeText(NextActivity.this, "Failed to update booking", Toast.LENGTH_SHORT).show());
                    } else {
                        Toast.makeText(NextActivity.this, "Booking not found", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void deleteBooking(String date, String timeSlot) {
        db.collection("bookings")
                .whereEqualTo("date", date)
                .whereEqualTo("timeSlot", timeSlot)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && !task.getResult().isEmpty()) {
                        String bookingId = task.getResult().getDocuments().get(0).getId();
                        db.collection("bookings").document(bookingId).delete()
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(NextActivity.this, "Booking deleted", Toast.LENGTH_SHORT).show();
                                    resetButtons(); // Reset button colors
                                    editTextDate.setText(""); // Clear date field
                                    selectedTime = ""; // Clear selected time
                                })
                                .addOnFailureListener(e -> Toast.makeText(NextActivity.this, "Failed to delete booking", Toast.LENGTH_SHORT).show());
                    } else {
                        Toast.makeText(NextActivity.this, "Booking not found", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}

