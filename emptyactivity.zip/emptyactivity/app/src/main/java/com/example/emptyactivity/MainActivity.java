package com.example.emptyactivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private boolean isAdminMode = false; // Variable to track admin mode

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseApp.initializeApp(getApplicationContext());

        setContentView(R.layout.activity_main);

        // Find views by ID
        EditText editTextUsername = findViewById(R.id.editTextUsername);
        EditText editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        ImageButton imageButton = findViewById(R.id.imageButton8);
        Switch switchLoginMode = findViewById(R.id.switchLoginMode);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Listen to switch changes
        switchLoginMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isAdminMode = isChecked;
            if (isAdminMode) {
                // If in admin mode
                editTextUsername.setHint(getString(R.string.hint_admin_username));
                editTextPassword.setHint(getString(R.string.hint_admin_password));
                Toast.makeText(this, "Admin Mode", Toast.LENGTH_SHORT).show();
            } else {
                // If in user mode
                editTextUsername.setHint(getString(R.string.hint_username));
                editTextPassword.setHint(getString(R.string.hint_password));
                Toast.makeText(this, "User Mode", Toast.LENGTH_SHORT).show();
            }
        });

        // Set a click listener for the login button
        buttonLogin.setOnClickListener(view -> {
            // Retrieve selected department, username, and password

            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            if (isAdminMode) {
                handleAdminLogin(username, password);
            } else {
                handleUserLogin(username, password);
            }
        });

        // Set a click listener for the image button
        imageButton.setOnClickListener(view -> {
            // Open the website
            openWebsite("https://www.tce.edu/");
        });
    }

    private void handleUserLogin(String username, String password) {
        mAuth.signInWithEmailAndPassword(username, password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Intent i = new Intent(MainActivity.this, NextActivity.class);
                startActivity(i);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleAdminLogin(String username, String password) {
        // Simple hardcoded check for admin credentials (can be replaced with more secure logic)
        if (username.equals("srisa@gmail.com") && password.equals("sri@123")) {
            // Sign in with Firebase
            mAuth.signInWithEmailAndPassword(username, password)
                    .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Intent i = new Intent(MainActivity.this, AdminDashboardActivity.class);
                            startActivity(i);
                            finish();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MainActivity.this, "Login Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            Toast.makeText(MainActivity.this, "Invalid Admin Credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void openWebsite(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}
