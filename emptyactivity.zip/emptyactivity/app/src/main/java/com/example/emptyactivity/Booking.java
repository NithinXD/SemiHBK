package com.example.emptyactivity;
public class Booking {
    public String date;
    public String timeSlot;
    public String name;
    public String department;
    public String purpose;

    public Booking() {
        // Default constructor required for calls to DataSnapshot.getValue(Booking.class)
    }

    public Booking(String date, String timeSlot, String name, String department, String purpose) {
        this.date = date;
        this.timeSlot = timeSlot;
        this.name = name;
        this.department = department;
        this.purpose = purpose;
    }
}
